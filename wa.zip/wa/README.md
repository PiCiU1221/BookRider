# Web App - v1.0

## Overview
This is the **web app** for a **library book delivery platform** designed to serve as an interface between our system and **librarians**, **library admins**, and **system administrators**. 

## 📸 Screenshots

![Landing Page](docs/landing-page.png)